package beta.project.quiz;

public class Quizz {
    int id;
    String nameq;
    int nb_passes;
    int[] ids_questions;
    public Quizz(int id,String name,int nbp, int[] idqs) {
        this.id = id;
        this.nameq = name;
        ids_questions=idqs;
        nb_passes = nbp;
    }
}