J'ai créer la présentation avec LibreOffice puis j'ai convertit le fichier en pptx
S'il y a de problème avec le fichier PP, veuillez lire l'original en ligne
